function [V,PR,S] = Prod_GR4J(S,x,V,PR,P,E);
% Function calculates Production of GR4J Model By T. Benkaci
% The version of model is GR4J (Perrin 2000, et Perrin et al., 2003)
% Accoerding to GR4J Model Fortran (CEMAGREF)
% FONCTION PRODUCTION 
%Reservoir sol
if P >= E, 
  ES=0;
 WS=(P-E)/x(1);
 if(WS>13);WS=13;end;
PS=(x(1)*(1-(V(1)/x(1))^2)*tanh(WS)/(1+(V(1)/x(1))*tanh(WS)));
 V(1)=V(1)+PS;
PR=(P-E)-PS; 
else
    PS=0;
    PR=0;
WS=(E-P)/x(1);
     if(WS>13);WS=13;end;
ES=V(1)*(2-(V(1)/x(1)))*tanh(WS)/(1+(1-(V(1)/x(1)))*tanh(WS));  
V(1)=V(1)-ES;
end;


if V(1) <= 0.0, 
    QS = 0;
else
   V1=V(1)/(1+(V(1)/2.25/x(1))^4.)^(0.25)  ;
 
    QS=V(1)-V1;
    V(1)=V1;
end;

PR=PR+QS;


