% SARR Sensitivity- Uncertainty Analysis of Rainfall-Runoff Model
%2 models: GR4J and IHACRES Models, & 2 Methods PAWN and RSA Methods
%Special Thanks to Dr Pianosi (francesca.pianosi@bristol.ac.uk), 
% Pr Wagener (Thorsten.Wagener@bristol.ac.uk) & Dr F. Sarrasin 
%    to provide PAWN & RSA matlab codes.
clc; clear all; close all
% mail to: francesca.pianosi@bristol.ac.uk

%% Step 1: Add paths

my_dir = pwd ; % use the 'pwd' command if you have already setup the Matlab
% current directory to the SAFE directory. Otherwise, you may define
% 'my_dir' manually by giving the path to the SAFE directory, e.g.:
% my_dir = '/Users/francescapianosi/Documents/safe_R1.0';

% Set current directory to 'my_dir' and add path to sub-folders:
cd(my_dir)
addpath(genpath(my_dir))

%% Step 2: setup the IHAC (Modified IHACRES model) By Dr Tarik benkaci
data=load('File_Data.txt');
P = data(1:731,1); % Rainfall data (mm/d) % 2 Years ---- 3 Years is enough do not use more than 5 Years 
E = data(1:731,2); % Evapotranspitation (mm/d) 
Qobs=data(1:731,3); % Observed Runoff 
rain=P; %Rainfall (mm/d)
evap=E; % PET (mm/d)
flow=Qobs; % Observed flow (mm/d)

% Define uncertain inputs (parameters):
M = 6 ; % number of inputs
labelparams={ 'X1','X2','X3','X4', 'X5', 'X6'} ; % input names
% parameter ranges:
xmin=[10.0    0.05    5.    0.05    0.5    2.0];
xmax=[700.0    0.95  100.0    0.99    1.99  220. ];  
distrpar=cell(M,1); for i=1:M; distrpar{i}=[xmin(i) xmax(i)]; end

% Define model output:
fun_test = 'IHACRES_max';

%% Step 3: Apply PAWN

NU = 120 ; % number of samples to estimate unconditional CDF
NC = 100 ; % number of samples to estimate conditional CDFs
n  = 10 ; % number of conditioning points

% Create input/output samples to estimate the unconditional output CDF:
Xu = AAT_sampling('lhs',M,'unif',distrpar,NU); % matrix (NU,M)
Yu = model_evaluation(fun_test,Xu,rain,evap)  ; % vector (1,M)

% Create input/output samples to estimate the conditional output CDFs:
[ XX, xc ] = pawn_sampling('lhs',M,'unif',distrpar,n,NC);
YY = pawn_model_evaluation(fun_test,XX,rain,evap) ;

% Estimate unconditional and conditional CDFs:
[ YF, Fu, Fc  ] = pawn_cdfs(Yu,YY) ;

% Plot CDFs:
figure
for i=1:M
   subplot(1,M,i)
  pawn_plot_cdf(YF, Fu, Fc(i,:),[],'y (max flow)')
end

% Further analyze CDF of one input:
i = 3 ;
figure;
pawn_plot_cdf(YF, Fu, Fc(i,:),xc{i},'y (max flow)',labelparams{i}) % same
% function as before but exploiting more optional input arguments

% Compute KS statistics:
KS = pawn_ks(YF,Fu,Fc) ;

% Plot KS statistics:
figure
for i=1:M
   subplot(1,M,i)
   pawn_plot_kstest(KS(:,i),NC,NU,0.05,xc{i},labelparams{i})
end

% Compute PAWN index by taking a statistic of KSs (e.g. max):
Pi = max(KS);

% Plot:
figure 
boxplot1(Pi,labelparams)

% Use bootstrapping to assess robustness of PAWN indices:
stat = 'max' ; % statistic to be applied to KSs
Nboot = 100  ; % number of boostrap resamples
[ T_m, T_lb, T_ub ] = pawn_indices(Yu,YY,stat,[],Nboot);

% Plot:
figure; boxplot1(T_m,labelparams,[],T_lb,T_ub)

% Convergence analysis:
stat = 'max' ; % statistic to be applied to KSs
NCb = [ NC/10 NC/2 NC ] ;
NUb = [ NU/10 NU/2 NU ] ;

[ T_m_n, T_lb_n, T_ub_n ] = pawn_convergence( Yu, YY, stat, NUb, NCb,[],Nboot );
NN = NUb+n*NCb ;
figure; plot_convergence(T_m_n,NN,T_lb_n,T_ub_n,[],'no of evals',[],labelparams)

%% Step 4: Apply PAWN to sub-region of the output range

% Compute the PAWN index over a sub-range of the output distribution, for
% instance only output values above a given threshold
thres = 50 ;
[ T_m2, T_lb2, T_ub2 ]= pawn_indices( Yu, YY, stat,[], Nboot,[],'above',thres ) ;

% Plot:
figure; boxplot1(T_m2,labelparams,[],T_lb2,T_ub2)


