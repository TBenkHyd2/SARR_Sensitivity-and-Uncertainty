% SARR Sensitivity- Uncertainty Analysis of Rainfall-Runoff Model
%2 models: GR4J and IHACRES Models, & 2 Methods PAWN and RSA Methods
%Special Thanks to Dr Pianosi (francesca.pianosi@bristol.ac.uk), 
% Pr Wagener (Thorsten.Wagener@bristol.ac.uk) & Dr F. Sarrasin 
%    to provide PAWN & RSA matlab codes.
clc; clear all; close all
% In this code we use RSA Method For GR4J model
% This script provides an application example of Regional Sensitivity Analysis (RSA)
% METHODS: % This script provides an example of application of Regional Sensitivity
% Analysis (RSA). RSA is applied in two different ways:
%
% - according to the original formulation
% where the input samples are split into two datasets depending on whether
% the corresponding output satisfies a threshold condition 
% >> matlab functions: RSA_indices_thres, RSA_plot_thres, RSA_convergence_thres
% (see help of 'RSA_indices_thres' for more details and references)
%
% - splitting the input samples into 'ngroup' datasets corresponding to 
% equally spaced ranges of the output
% >> matlab functions: RSA_indices_groups, RSA_plot_groups, RSA_convergence_groups
% (see help of 'RSA_indices_groups' for more details and references)
%
% MODEL AND STUDY AREA
% we apply RSA method to GR4J Model
% INDEX
% Steps:
% 1. Add paths to required directories
% 2. Load data and set-up the Hymod model
% 3. Sample inputs space
% 4. Run the model against input samples
% 5a. Perform RSA with thresholds or % 5b. Perform RSA with groups
% This script prepared by Francesca Pianosi and Fanny Sarrazin
% University of Bristol, 2014
% mail to: francesca.pianosi@bristol.ac.uk

%% Step 1 (add paths)
my_dir = pwd ; % use the 'pwd' command if you have already setup the Matlab
% current directory to the SAFE directory. Otherwise, you may define
% 'my_dir' manually by giving the path to the SAFE directory, e.g.:
% my_dir = '/Users/francescapianosi/Documents/safe_R1.0';

% Set current directory to 'my_dir' and add path to sub-folders:
cd(my_dir)
addpath(genpath(my_dir))

%% Step 2 (setup the GR4J model ) By Dr Tarik benkaci:
% Load data:
data=load('File_Data.txt');
P = data(1:731,1); % Rainfall Data file (mm/d)
E = data(1:731,2); % Evapotranspiration Data file (mm/d)
Qobs=data(1:731,3); % Observed Target Flow Data file (mm/d)
rain=P; % (mm/d)
evap=E; % (mm/d)
flow=Qobs; % (mm/d)

DistrFun  = 'unif'  ; % Parameter distribution
DistrPar  = { [ 10 800 ]; [ -20 20 ]; [ 2 150 ]; [ .8  3.5 ]  } ; % Parameters range of GR4J Model do not change this
x_labels = {'X1','X2','X3','X4'} ;

% Define output:
myfun = 'GR4J_MulObj' ;

%% Step 3 (sample inputs space)
SampStrategy = 'lhs' ; % Latin Hypercube
N = 3000 ; % Number of samples
M = length(DistrPar) ; % Number of inputs
X = AAT_sampling(SampStrategy,M,DistrFun,DistrPar,N);

%% Step 4 (run the model) 
Y = model_evaluation(myfun,X,rain,evap,flow) ;

%% Step 5a (Regional Sensitivity Analysis with threshold)

% Visualize input/output samples (this may help finding a reasonable value
% for the output threshold):
figure; scatter_plots(X,Y(:,1),[],'rmse',x_labels) ;
figure; scatter_plots(X,Y(:,2),[],'bias',x_labels) ;

% Set output threshold:
rmse_thres = 1.6   ; %  threshold for the first obj. fun.
bias_thres = 1.1 ; % behavioural threshold for the second obj. fun.

% RSA (find behavioural parameterizations):
threshold = [ rmse_thres bias_thres ] ;
[mvd,idxb] = RSA_indices_thres(X,Y,threshold) ;

% Highlight the behavioural parameterizations in the scatter plots:
figure; scatter_plots(X,Y(:,1),[],'rmse',x_labels,idxb) ;
figure; scatter_plots(X,Y(:,2),[],'bias',x_labels,idxb) ;

% Plot parameter CDFs:
RSA_plot_thres(X,idxb,[],x_labels,{'behav','non-behav'}); % add legend

% Check the ranges of behavioural parameterizations by
% Parallel coordinate plot:
parcoor(X,x_labels,[],idxb)

% Plot the sensitivity indices (maximum vertical distance between
% parameters CDFs):
figure; boxplot1(mvd,x_labels,'mvd')

% Assess robustness by bootstrapping:
Nboot = 100;
[mvd,idxb,mvd_lb,mvd_ub] = RSA_indices_thres(X,Y,threshold,[],Nboot);
% Plot results:
boxplot1(mvd,x_labels,'mvd',mvd_lb,mvd_ub)

% Repeat computations using an increasing number of samples so to assess
% convergence:
NN = [ N/5:N/5:N ] ;
mvd = RSA_convergence_thres(X,Y,NN,threshold) ;
% Plot the sensitivity measures (maximum vertical distance between
% parameters CDFs) as a function of the number of samples:
figure; plot_convergence(mvd,NN,[],[],[],'no of samples','mvd',x_labels)

% Repeat convergence analysis using bootstrapping to derive confidence
% bounds:
Nboot = 100;
[mvd_mean,mvd_lb,mvd_ub]  = RSA_convergence_thres(X,Y,NN,threshold,[],Nboot) ;
figure
plot_convergence(mvd_mean,NN,mvd_lb,mvd_ub,[],'no of samples','mvd',x_labels)

%% Step 5b (Regional Sensitivity Analysis with groups)

% RSA (find behavioural parameterizations):
[stat,idx,Yk] = RSA_indices_groups(X,Y(:,1)) ;

% Plot parameter CDFs:
RSA_plot_groups(X,idx,Yk) ;
% Customize labels and legend:
RSA_plot_groups(X,idx,Yk,[],x_labels,'rmse'); % add legend

